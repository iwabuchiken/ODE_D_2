===============================================
Library and Header files for the Dev-Cpp Compiler
===============================================

In this zip file you will find one file called libode.a, two dll files called 'libode.dll' and 'libopcode.dll' and a folder called 'ode'. Copy the libode.a file to the lib folder of your compiler and copy the folder to the include folder of your compiler. The DLL files must be placed in your projects folder with the executable or be found somewhere on your environment path. I have only made one change to the config.h file which is located in the ode folder; this was due to a conflicting definition of int32 in winsock2.h.

The source code for ODE was released under the GNU Lesser General Public License http://www.opensource.org/licenses/lgpl-license.html or the BSD-style license http://opende.sourceforge.net/ode-license.html and you can download the complete source code and binaries for ODE at the official ode webite at http://www.q12.org. Thanks go to Russell Smith for developing ODE and releasing it as an open source project.